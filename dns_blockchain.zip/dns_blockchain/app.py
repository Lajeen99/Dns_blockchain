from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from web3 import Web3
from web3.middleware import geth_poa_middleware
from eth_account import Account
from flask_migrate import Migrate
from bit import PrivateKeyTestnet
from bit.network import NetworkAPI
from ecdsa import SigningKey, SECP256k1
from datetime import datetime
import sqlite3
import secrets

# Initialize Flask application
app = Flask(__name__)

# Set a secret key for session management
app.secret_key = secrets.token_hex(16)

# Configure the SQLAlchemy database URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///recovered.db'
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'connect_args': {'timeout': 30}}

# Initialize SQLAlchemy with the Flask application
db = SQLAlchemy(app)
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:5000'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
migrate = Migrate(app, db)


# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(30), nullable=False)
    last_name = db.Column(db.String(30), nullable=False)
    cga = db.Column(db.String(42), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone_number = db.Column(db.String(10), nullable=False)
    password = db.Column(db.String(60), nullable=False)
    eth_balance = db.Column(db.Float, default=0.0)
    eth_private_key = db.Column(db.String(64))

    def __init__(self, **kwargs):
      super(User, self).__init__(**kwargs)
      self.cga = generate_unique_cga()

# Define the Transaction model
class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    receiver_address = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    sender_address = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    receiver = db.relationship('User', foreign_keys=[receiver_address], backref='received_transactions')
    sender = db.relationship('User', foreign_keys=[sender_address], backref='sent_transactions')

# Create tables explicitly
with app.app_context():
    db.create_all()

def generate_unique_cga():
    # Generate a unique CGA value
    while True:
        cga = secrets.token_hex(21)  # 42 characters
        if not User.query.filter_by(cga=cga).first():
            return cga


# Function to generate public and private keys
def generate_keys():
    private_key = SigningKey.generate(curve=SECP256k1)
    public_key = private_key.get_verifying_key()
    private_key_hex = private_key.to_string().hex()
    public_key_hex = public_key.to_string().hex()
    return private_key_hex, public_key_hex


def send_eth_transaction(eth_private_key, receiver_gca, amount):
    """
    Sends Ethereum from the user's wallet to the receiver address.

    Args:
    - private_key (str): User's Ethereum private key.
    - receiver_address (str): Receiver's Ethereum address.
    - amount (float): Amount of Ethereum to send.

    Returns:
    - tx_hash (str): Transaction hash of the sent transaction.
    """
    # Create an account object using the private key
    account = Account.from_key(private_key)

    # Convert the receiver address to checksum format
    receiver_address = Web3.toChecksumAddress(receiver_address)

    # Get the current nonce for the sender address
    nonce = w3.eth.getTransactionCount(account.address)

    # Create a transaction dictionary
    tx = {
        'to': receiver_address,
        'value': w3.toWei(amount, 'ether'),  # Convert amount to wei
        'gas': 21000,  # Gas limit for a standard transaction
        'gasPrice': w3.eth.gasPrice,
        'nonce': nonce,
        'chainId': 1  # Mainnet
    }

    # Sign the transaction with the sender's private key
    signed_tx = w3.eth.account.signTransaction(tx, private_key)

    # Send the signed transaction
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)

    return tx_hash



# Define routes and other application logic
@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
     if request.method == 'POST':
        cga = request.form['cga']
        password = request.form['password']
        user = User.query.filter_by(cga=cga).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            flash('You have been logged in!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Please check your email and password.', 'error')
            return redirect(url_for('welcome'))

     return render_template('login.html', user=user)


@app.route('/dashboard')
def dashboard():

    user_id = session.get('user_id')
    if user_id:
        user = User.query.get(user_id)
        if user:
             # Retrieve Ethereum address from the session or generate it if not present
            eth_address = session.get('eth_address') or Account.from_key(user.eth_private_key).address
            return render_template('login.html', user=user)
        else:
            flash('User not found.', 'error')
            return redirect(url_for('welcome'))
    else:
        flash('User not authenticated.', 'error')
        return redirect(url_for('welcome'))


from flask import request

@app.route('/send_ethereum', methods=['GET', 'POST'])
def send_ethereum():
    if request.method == 'POST':
        # Handle POST request to send Ethereum
        # Extract form data and process the Ethereum transaction
        receiver_address = request.form.get('receiver_address')
        amount = float(request.form.get('amount'))
        reference = request.form.get('reference')

        # Validate form data and perform Ethereum transaction
        if not all([receiver_address, amount, reference]):
            return "Incomplete form data", 400  # Bad Request

        # Retrieve user ID from session
        user_id = session.get('user_id')
        if user_id:
            sender = User.query.get(user_id)
            if sender:
                # Verify sender's balance
                if sender.eth_balance >= amount:
                    # Retrieve receiver's user data
                    receiver = User.query.filter_by(eth_address=receiver_address).first()
                    if receiver:
                        try:
                            # Fetch sender's private key from the database
                            sender_private_key = sender.eth_private_key

                            # Send Ethereum transaction
                            tx_hash = send_eth_transaction(sender_private_key, receiver_address, amount)

                            # Update sender and receiver balances
                            sender.eth_balance -= amount
                            receiver.eth_balance += amount

                            # Save transaction data
                            new_transaction = Transaction(sender_address=sender.eth_address, receiver_address=receiver_address,
                                                          amount=amount, currency='ETH', reference=reference)
                            db.session.add(new_transaction)
                            db.session.commit()

                            # Redirect to success page
                            flash('Transaction successful!', 'success')
                            return redirect(url_for('send_success'))
                        except Exception as e:
                            flash(f'Transaction failed: {str(e)}', 'error')
                    else:
                        flash('Receiver not found.', 'error')
                else:
                    flash('Insufficient balance.', 'error')
            else:
                flash('User not found.', 'error')
    else:
        # Handle GET request to render the form
        return render_template('send_ethereum.html')

    # Default case if no action taken
    return "Method Not Allowed", 405  # Method Not Allowed




@app.route('/forgot-password')
def forgot_password():
    return render_template('reset_password.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form['firstName']
        last_name = request.form['lastName']
        email  = request.form['email']
        phone_number = request.form['phone_number']
        password = request.form['password']
        confirm_password = request.form['confirmPassword']
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
        else:
            hashed_password = generate_password_hash(password)
            eth_private_key = Account.create().key.hex()
            eth_address = Account.from_key(eth_private_key).address
            new_user = User(first_name=first_name, last_name=last_name, email=email, cga=eth_address, phone_number=phone_number,
                            password=hashed_password, eth_private_key=eth_private_key)
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful. Please log in.', 'success')
            return redirect(url_for('login'))
    return render_template('register.html')




@app.route('/send_success')
def send_success():
    return render_template('send_success.html')



@app.route('/settings')
def settings():
    return render_template('settings.html')


@app.route('/transactions')
def transactions():
    return render_template('transactions.html')


@app.route('/terms')
def terms():
    return render_template('terms.html')


@app.route('/help')
def help():
    return render_template('help.html')


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        email = request.form['email']
        phone_number = request.form['phone_number']
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        # Validate form data
        if not all([email,phone_number, current_password, new_password, confirm_password]):
            flash('All fields are required', 'error')
        elif new_password != confirm_password:
            flash('Passwords do not match', 'error')
        else:
            # Check if the email exists in the database
            user = User.query.filter_by(email=email).first()
            if user:
                # Verify the current password
                if check_password_hash(user.password, current_password):
                   if user.phone_number == phone_number:
                        # Update the user's password
                        user.password = generate_password_hash(new_password)
                        db.session.commit()
                        flash('Password successfully reset.', 'success')
                        return redirect(url_for('dashboard'))
                   else:
                        flash('Phone number does not match the registered number.', 'error')
                else:
                    flash('Incorrect current password.', 'error')
            else:
                flash('Email not found. Please enter a registered email.', 'error')

    return render_template('reset_password.html')


@app.route('/update-email', methods=['GET', 'POST'])
def update_email():
    if request.method == 'POST':
        phone_number = request.form['phone_number']
        new_email = request.form['newEmail']


        # Validate form data
        if not all([phone_number, new_email]):
            flash('All fields are required', 'error')
        else:
            # Retrieve user ID from the session
            user_id = session.get('user_id')
            if user_id:
                # Get the user from the database
                user = User.query.get(user_id)
                if user:
                    # Check if the provided phone number matches the user's registered phone number
                    if user.phone_number == phone_number:
                        # Update the user's email address
                        user.email = new_email
                        db.session.commit()
                        flash('Email address updated successfully.', 'success')
                        return redirect(url_for('settings'))
                    else:
                        flash('Phone number does not match the registered number.', 'error')
                else:
                    flash('User not found.', 'error')
            else:
                flash('User not authenticated.', 'error')

    return render_template('update_email.html')


@app.errorhandler(404)
def page_not_found(error):
    return render_template('error.html'), 404


@app.route('/logout', methods=['GET', 'POST'])
def logout():

    session.pop('user_id', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('welcome'))


@app.route('/transactions')
def view_transactions():
    if 'user_id' not in session:
        flash('You need to log in first.', 'error')
        return redirect(url_for('login'))
    user_id = session['user_id']
    user = User.query.get(user_id)
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('login'))
    transactions = Transaction.query.filter_by(sender=user.eth_address).all()
    return render_template('transactions.html', transactions=transactions)


# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
